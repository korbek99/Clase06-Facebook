//
//  Bridging-Header.h
//  FacebookTutorial
//
//  Created by Brian Coleman on 2015-03-27.
//  Copyright (c) 2015 Brian Coleman. All rights reserved.
//

#ifndef FacebookTutorial_Bridging_Header_h
#define FacebookTutorial_Bridging_Header_h

#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>

#endif
